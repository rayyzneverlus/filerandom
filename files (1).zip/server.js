/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║          CDN Server v2.0 — cdn.farel.biz.id              ║
 * ║   Local Storage · File Expiry · Premium Dashboard        ║
 * ╚══════════════════════════════════════════════════════════╝
 *  Author : Farel
 *  Stack  : Node.js + Express + node-cron
 */

'use strict';

const express     = require('express');
const cors        = require('cors');
const compression = require('compression');
const helmet      = require('helmet');
const morgan      = require('morgan');
const path        = require('path');
const fs          = require('fs');
const mime        = require('mime-types');
const multer      = require('multer');
const { v4: uuidv4 } = require('uuid');
const os          = require('os');
const cron        = require('node-cron');

const app        = express();
const PORT       = process.env.PORT  || 3000;
const HOST       = process.env.HOST  || '0.0.0.0';
const START_TIME = Date.now();

// ── Directories ───────────────────────────────────────────────────────────────
const STORAGE_DIR  = path.join(__dirname, 'storage');
const META_FILE    = path.join(__dirname, 'storage', '_meta.json');

[STORAGE_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ── Expiry presets (ms) ───────────────────────────────────────────────────────
const EXPIRY_PRESETS = {
  '1h'   : 60 * 60 * 1000,
  '6h'   : 6  * 60 * 60 * 1000,
  '12h'  : 12 * 60 * 60 * 1000,
  '1d'   : 24 * 60 * 60 * 1000,
  '3d'   : 3  * 24 * 60 * 60 * 1000,
  '7d'   : 7  * 24 * 60 * 60 * 1000,
  '30d'  : 30 * 24 * 60 * 60 * 1000,
  '90d'  : 90 * 24 * 60 * 60 * 1000,
  'never': null
};

// ── Metadata Store ────────────────────────────────────────────────────────────
// Structure: { [fileId]: { id, filename, original, folder, size, mimetype,
//                          uploaded_at, expires_at, downloads, tags } }
function readMeta() {
  try {
    if (fs.existsSync(META_FILE)) return JSON.parse(fs.readFileSync(META_FILE, 'utf8'));
  } catch (_) {}
  return {};
}

function writeMeta(data) {
  fs.writeFileSync(META_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function getMeta(id) {
  return readMeta()[id] || null;
}

function setMeta(id, obj) {
  const m = readMeta();
  m[id] = obj;
  writeMeta(m);
}

function deleteMeta(id) {
  const m = readMeta();
  delete m[id];
  writeMeta(m);
}

// ── Multer ────────────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const folder = (req.params.folder || 'default').replace(/[^a-zA-Z0-9_-]/g, '_');
    const dest   = path.join(STORAGE_DIR, folder);
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext  = path.extname(file.originalname).toLowerCase();
    const base = req.query.filename
      ? req.query.filename.replace(/[^a-zA-Z0-9_.-]/g, '_')
      : uuidv4();
    cb(null, base + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 } // 500 MB
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function bytesToHuman(bytes) {
  if (!bytes) return '0 B';
  const u = ['B','KB','MB','GB','TB'];
  let i = 0;
  while (bytes >= 1024 && i < u.length - 1) { bytes /= 1024; i++; }
  return `${bytes.toFixed(2)} ${u[i]}`;
}

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600),
        m = Math.floor((s % 3600) / 60), sec = s % 60;
  return `${d}d ${h}h ${m}m ${sec}s`;
}

function getDirStats(dir) {
  let count = 0, size = 0;
  if (!fs.existsSync(dir)) return { count, size: '0 B', raw: 0 };
  const walk = d => fs.readdirSync(d).forEach(f => {
    const fp = path.join(d, f);
    const st = fs.statSync(fp);
    if (st.isDirectory()) walk(fp);
    else if (!f.startsWith('_')) { count++; size += st.size; }
  });
  walk(dir);
  return { count, size: bytesToHuman(size), raw: size };
}

function resolveExpiry(preset, customMs) {
  if (customMs) return Date.now() + parseInt(customMs);
  if (preset && EXPIRY_PRESETS[preset] !== undefined) {
    return EXPIRY_PRESETS[preset] === null ? null : Date.now() + EXPIRY_PRESETS[preset];
  }
  return Date.now() + EXPIRY_PRESETS['7d']; // default 7 days
}

function isExpired(meta) {
  if (!meta.expires_at) return false;
  return Date.now() > meta.expires_at;
}

function deleteFile(meta) {
  const fp = path.join(STORAGE_DIR, meta.folder, meta.filename);
  try { if (fs.existsSync(fp)) fs.unlinkSync(fp); } catch (_) {}
  deleteMeta(meta.id);
}

// ── Expiry cron job — runs every 5 minutes ────────────────────────────────────
cron.schedule('*/5 * * * *', () => {
  const meta = readMeta();
  let purged = 0;
  Object.values(meta).forEach(m => {
    if (isExpired(m)) { deleteFile(m); purged++; }
  });
  if (purged > 0) console.log(`[cron] Purged ${purged} expired file(s)`);
});

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(compression());
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Add server timing header
app.use((req, res, next) => {
  res.setHeader('X-CDN', 'cdn.farel.biz.id');
  res.setHeader('X-Powered-By', 'Farel CDN v2');
  next();
});

// ── ROUTES ────────────────────────────────────────────────────────────────────

// GET / — Dashboard
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

// GET /ping — Health + server info
app.get('/ping', (req, res) => {
  const mem   = process.memoryUsage();
  const stats = getDirStats(STORAGE_DIR);
  const meta  = readMeta();
  const now   = Date.now();
  const active   = Object.values(meta).filter(m => !isExpired(m)).length;
  const expired  = Object.values(meta).filter(m => isExpired(m)).length;

  res.json({
    status   : 'ok',
    service  : 'cdn.farel.biz.id',
    version  : '2.0.0',
    timestamp: new Date().toISOString(),
    uptime: {
      ms    : now - START_TIME,
      human : formatUptime(now - START_TIME),
      process: Math.floor(process.uptime())
    },
    nodejs: {
      version : process.version,
      platform: process.platform,
      arch    : process.arch,
      pid     : process.pid
    },
    server: {
      hostname : os.hostname(),
      os       : `${os.type()} ${os.release()}`,
      cpus     : os.cpus().length,
      cpu_model: os.cpus()[0]?.model || 'N/A',
      load_avg : { '1m': os.loadavg()[0], '5m': os.loadavg()[1], '15m': os.loadavg()[2] },
      memory: {
        total: bytesToHuman(os.totalmem()),
        free : bytesToHuman(os.freemem()),
        used : bytesToHuman(os.totalmem() - os.freemem()),
        process: {
          rss      : bytesToHuman(mem.rss),
          heapTotal: bytesToHuman(mem.heapTotal),
          heapUsed : bytesToHuman(mem.heapUsed)
        }
      }
    },
    storage: {
      total_files : stats.count,
      total_size  : stats.size,
      active_files: active,
      expired_pending: expired
    },
    expiry_presets: Object.keys(EXPIRY_PRESETS)
  });
});

// GET /api — API docs
app.get('/api', (req, res) => {
  res.json({
    service : 'cdn.farel.biz.id',
    version : '2.0.0',
    base_url: 'https://cdn.farel.biz.id',
    expiry_presets: EXPIRY_PRESETS,
    endpoints: [
      { method:'GET',    path:'/',                             description:'Premium CDN dashboard' },
      { method:'GET',    path:'/ping',                         description:'Health check, Node.js info, server metrics, storage stats' },
      { method:'GET',    path:'/api',                          description:'API documentation (this page)' },
      { method:'POST',   path:'/api/upload/:folder',           description:'Upload file to folder with optional expiry',
        body:'multipart/form-data field: file',
        query:{ filename:'custom filename', expires:'preset (1h/6h/12h/1d/3d/7d/30d/90d/never)', expires_ms:'custom TTL in ms', tags:'comma-separated tags' },
        returns:'id, url, filename, folder, size, mimetype, expires_at, expires_in' },
      { method:'GET',    path:'/api/files',                    description:'List all files with metadata and expiry info' },
      { method:'GET',    path:'/api/files/:folder',            description:'List files in a specific folder' },
      { method:'GET',    path:'/api/files/:folder/:id',        description:'Get single file metadata by ID' },
      { method:'PATCH',  path:'/api/files/:id/expiry',         description:'Update expiry of an existing file', body:{ expires:'preset', expires_ms:'custom TTL in ms' } },
      { method:'GET',    path:'/api/folders',                  description:'List all folders with file counts and sizes' },
      { method:'DELETE', path:'/api/files/:id',                description:'Delete a file by its ID' },
      { method:'DELETE', path:'/api/purge-expired',            description:'Manually purge all expired files now' },
      { method:'GET',    path:'/f/:folder/:filename',          description:'Serve / stream CDN file (public URL)' },
      { method:'GET',    path:'/api/stats',                    description:'Storage & expiry statistics per folder' }
    ]
  });
});

// POST /api/upload/:folder — Upload
app.post('/api/upload/:folder', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file. Use field name "file".' });

  const folder    = (req.params.folder || 'default').replace(/[^a-zA-Z0-9_-]/g, '_');
  const id        = uuidv4();
  const expiresAt = resolveExpiry(req.query.expires, req.query.expires_ms);
  const tags      = req.query.tags ? req.query.tags.split(',').map(t => t.trim()) : [];
  const fileUrl   = `${req.protocol}://${req.get('host')}/f/${folder}/${req.file.filename}`;

  const meta = {
    id,
    filename    : req.file.filename,
    original    : req.file.originalname,
    folder,
    size        : req.file.size,
    size_human  : bytesToHuman(req.file.size),
    mimetype    : req.file.mimetype,
    url         : fileUrl,
    uploaded_at : new Date().toISOString(),
    expires_at  : expiresAt,
    expires_in  : expiresAt ? Math.max(0, expiresAt - Date.now()) : null,
    tags,
    downloads   : 0
  };

  setMeta(id, meta);

  res.status(201).json({
    status     : 'uploaded',
    ...meta,
    expires_iso: expiresAt ? new Date(expiresAt).toISOString() : 'never'
  });
});

// GET /api/files — List all
app.get('/api/files', (req, res) => {
  const meta  = readMeta();
  const now   = Date.now();
  const files = Object.values(meta)
    .filter(m => !m.filename.startsWith('_'))
    .map(m => ({
      ...m,
      is_expired : isExpired(m),
      expires_in : m.expires_at ? Math.max(0, m.expires_at - now) : null,
      expires_iso: m.expires_at ? new Date(m.expires_at).toISOString() : 'never'
    }))
    .sort((a, b) => new Date(b.uploaded_at) - new Date(a.uploaded_at));

  res.json({ total: files.length, files });
});

// GET /api/files/:folder — List by folder
app.get('/api/files/:folder', (req, res) => {
  const meta  = readMeta();
  const now   = Date.now();
  const files = Object.values(meta)
    .filter(m => m.folder === req.params.folder)
    .map(m => ({
      ...m,
      is_expired : isExpired(m),
      expires_in : m.expires_at ? Math.max(0, m.expires_at - now) : null
    }))
    .sort((a, b) => new Date(b.uploaded_at) - new Date(a.uploaded_at));

  res.json({ folder: req.params.folder, total: files.length, files });
});

// GET /api/files/:folder/:id — Single file metadata
app.get('/api/files/:folder/:id', (req, res) => {
  const m = getMeta(req.params.id);
  if (!m) return res.status(404).json({ error: 'File not found' });
  res.json({ ...m, is_expired: isExpired(m) });
});

// PATCH /api/files/:id/expiry — Update expiry
app.patch('/api/files/:id/expiry', (req, res) => {
  const m = getMeta(req.params.id);
  if (!m) return res.status(404).json({ error: 'File not found' });

  const newExpiry = resolveExpiry(req.body.expires || req.query.expires, req.body.expires_ms || req.query.expires_ms);
  m.expires_at = newExpiry;
  setMeta(req.params.id, m);

  res.json({
    status     : 'updated',
    id         : m.id,
    expires_at : newExpiry,
    expires_iso: newExpiry ? new Date(newExpiry).toISOString() : 'never',
    expires_in : newExpiry ? Math.max(0, newExpiry - Date.now()) : null
  });
});

// GET /api/folders — List folders
app.get('/api/folders', (req, res) => {
  if (!fs.existsSync(STORAGE_DIR)) return res.json({ folders: [] });
  const meta    = readMeta();
  const folderSet = {};
  Object.values(meta).forEach(m => {
    if (!folderSet[m.folder]) folderSet[m.folder] = { name: m.folder, file_count: 0, size: 0, active: 0, expired: 0 };
    folderSet[m.folder].file_count++;
    folderSet[m.folder].size += m.size || 0;
    if (isExpired(m)) folderSet[m.folder].expired++;
    else folderSet[m.folder].active++;
  });
  const folders = Object.values(folderSet).map(f => ({ ...f, size: bytesToHuman(f.size) }));
  res.json({ total: folders.length, folders });
});

// DELETE /api/files/:id — Delete by ID
app.delete('/api/files/:id', (req, res) => {
  const m = getMeta(req.params.id);
  if (!m) return res.status(404).json({ error: 'File not found' });
  deleteFile(m);
  res.json({ status: 'deleted', id: req.params.id, filename: m.filename });
});

// DELETE /api/purge-expired — Manual purge
app.delete('/api/purge-expired', (req, res) => {
  const meta = readMeta();
  let purged = 0;
  Object.values(meta).forEach(m => { if (isExpired(m)) { deleteFile(m); purged++; } });
  res.json({ status: 'purged', count: purged });
});

// GET /api/stats — Stats
app.get('/api/stats', (req, res) => {
  const meta   = readMeta();
  const overall = getDirStats(STORAGE_DIR);
  const byFolder = {};
  Object.values(meta).forEach(m => {
    if (!byFolder[m.folder]) byFolder[m.folder] = { name: m.folder, files: 0, size: 0, active: 0, expired: 0 };
    byFolder[m.folder].files++;
    byFolder[m.folder].size += m.size || 0;
    if (isExpired(m)) byFolder[m.folder].expired++;
    else byFolder[m.folder].active++;
  });
  const folders = Object.values(byFolder).map(f => ({ ...f, size: bytesToHuman(f.size) }));
  const now     = Date.now();
  const expiringSoon = Object.values(meta).filter(m => m.expires_at && m.expires_at - now < 86400000 && !isExpired(m));

  res.json({
    overall  : { files: overall.count, size: overall.size },
    active   : Object.values(meta).filter(m => !isExpired(m)).length,
    expired  : Object.values(meta).filter(m => isExpired(m)).length,
    expiring_within_24h: expiringSoon.length,
    folders
  });
});

// GET /f/:folder/:filename — Serve file
app.get('/f/:folder/:filename', (req, res) => {
  // Check metadata for expiry
  const meta  = readMeta();
  const match = Object.values(meta).find(m => m.folder === req.params.folder && m.filename === req.params.filename);

  if (match) {
    if (isExpired(match)) {
      deleteFile(match);
      return res.status(410).json({ error: 'File has expired and been removed.' });
    }
    // Increment downloads
    match.downloads = (match.downloads || 0) + 1;
    setMeta(match.id, match);
  }

  const fp = path.join(STORAGE_DIR, req.params.folder, req.params.filename);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'File not found' });

  const mimeType = mime.lookup(fp) || 'application/octet-stream';
  res.setHeader('Content-Type', mimeType);
  res.setHeader('Cache-Control', 'public, max-age=86400');
  if (match?.expires_at) {
    res.setHeader('Expires', new Date(match.expires_at).toUTCString());
  }
  res.sendFile(fp);
});

// 404
app.use((req, res) => res.status(404).json({ error: 'Not found', path: req.path }));

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, HOST, () => {
  console.log('\n╔══════════════════════════════════════╗');
  console.log('║     cdn.farel.biz.id  v2.0           ║');
  console.log('╚══════════════════════════════════════╝');
  console.log(`  ➜  http://${HOST}:${PORT}`);
  console.log(`  ➜  Node.js ${process.version} · ${process.platform}`);
  console.log(`  ➜  Storage: ${STORAGE_DIR}`);
  console.log(`  ➜  Expiry cron: every 5 min\n`);
});
